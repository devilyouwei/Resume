# Resume

Youwei's Resume website.

Know more about me?

Please visit my personal webiste: [www.devil.ren](https://www.devil.ren)

# 簡歷

黃有爲的個人簡歷

瞭解更多，請訪問：[www.devil.ren](https://www.devil.ren)

# 简历

黄有爲的个人简历

了解更多，请访问：[www.devil.ren](https://www.devil.ren)
